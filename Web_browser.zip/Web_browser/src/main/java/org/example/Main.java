package org.example;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage stage) {
        stage.setTitle("Simple Web Browser");

        TextField urlField = new TextField("https://www.google.com");
        Button goButton = new Button("Go");

        WebView webView = new WebView();
        WebEngine engine = webView.getEngine();
        engine.load(urlField.getText());

        goButton.setOnAction(e -> {
            String url = urlField.getText();
            if (!url.startsWith("http")) {
                url = "http://" + url;
            }
            engine.load(url);
        });

        HBox topBar = new HBox(urlField, goButton);
        BorderPane root = new BorderPane();
        root.setTop(topBar);
        root.setCenter(webView);

        Scene scene = new Scene(root, 1000, 700);
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}

