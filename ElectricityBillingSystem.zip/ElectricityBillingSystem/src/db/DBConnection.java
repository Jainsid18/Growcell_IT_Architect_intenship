package db;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.DriverManager;

public class DBConnection {
    private static final String URL="jdbc:mysql://localhost:3306/electricity_billing";
    private static final String User="root";
    private static final String Password="Siddhant@1811";

    public static Connection getConnection() throws SQLException
    {
        return DriverManager.getConnection(URL,User,Password);
    }
}
