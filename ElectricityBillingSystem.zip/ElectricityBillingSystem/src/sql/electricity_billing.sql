create database electricity_billing;
use electricity_billing;
create table customers(
id int auto_increment primary key,
name varchar(100),
address varchar(255),
meter_number varchar(20) unique
);

create table bills(
id int auto_increment primary key,
customer_id int,
unit_consumed double,
billing_date date,
amount double,
foreign key(customer_id) references customers(id)
);