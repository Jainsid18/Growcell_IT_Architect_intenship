package ui;

import dao.CustomerDAO;
import model.Customer;

import javax.swing.*;
import java.awt.*;

public class AddCustomerForm extends JFrame {
    public AddCustomerForm() {
        setTitle("Add New Customer");
        setSize(400, 300);
        setLayout(new GridLayout(5, 2, 10, 10));
        setLocationRelativeTo(null);

        JLabel nameLabel = new JLabel("Name:");
        JTextField nameField = new JTextField();

        JLabel addressLabel = new JLabel("Address:");
        JTextField addressField = new JTextField();

        JLabel meterLabel = new JLabel("Meter Number:");
        JTextField meterField = new JTextField();

        JButton saveBtn = new JButton("Save");

        saveBtn.addActionListener(e -> {
            String name = nameField.getText();
            String address = addressField.getText();
            String meterNo = meterField.getText();

            if (name.isEmpty() || address.isEmpty() || meterNo.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill all fields!");
                return;
            }

            Customer customer = new Customer(name, address, meterNo);
            boolean success = new CustomerDAO().addCustomer(customer);

            if (success) {
                JOptionPane.showMessageDialog(this, "Customer added successfully!");
                nameField.setText("");
                addressField.setText("");
                meterField.setText("");
            } else {
                JOptionPane.showMessageDialog(this, "Failed to add customer.");
            }
        });

        add(nameLabel); add(nameField);
        add(addressLabel); add(addressField);
        add(meterLabel); add(meterField);
        add(new JLabel()); add(saveBtn);

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setVisible(true);
    }
}
