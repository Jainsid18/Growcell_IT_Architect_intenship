package dao;

import db.DBConnection;
import model.Customer;

import java.sql.*;

public class CustomerDAO {
    public boolean addCustomer(Customer customer)
    {
        String sql="INSERT INTO customers(name,address,meter_number)VALUES(?,?,?)";

        try (Connection conn=DBConnection.getConnection(); PreparedStatement stmt=conn.prepareStatement(sql))
        {
            stmt.setString(1, customer.getName());
            stmt.setString(2, customer.getAddress());
            stmt.setString(3, customer.getMeterNumber());

            int rowsInserted = stmt.executeUpdate();
            return rowsInserted >0;
        } catch(SQLException e)
        {
            System.out.println(" Failed to insert customer: " + e.getMessage());
            return false;
        }
    }
}
