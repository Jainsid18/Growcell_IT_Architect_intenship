import db.DBConnection;

import java.sql.*;
import ui.AddCustomerForm;

public class Main {
    public static void main(String args[]) {
        new AddCustomerForm();
        try {
            Connection conn = DBConnection.getConnection();
            System.out.println("Connection to MySQL successfully!");
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
